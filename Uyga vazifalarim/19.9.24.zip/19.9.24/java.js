'use strict'

const heading1 = document.getElementById('heading1');
const heading3 = document.getElementById('heading3');
const heading4 = document.getElementById('heading4');
const paragraph = document.getElementById('paragraph');
const headingTort = document.getElementById('headingTort');
const box1 = document.getElementById('box1');
const box2 = document.getElementById('box2');
const box3 = document.getElementById('box3');
const btn = document.getElementById('event');

btn.addEventListener('click', function() {
    heading1.style.color = 'blue';
    
    heading1.style.fontSize = '45px';
    
    heading3.style.fontSize = '35px';
    
    heading4.style.fontSize = '40px';

    paragraph.style.color = 'red';
    paragraph.style.fontSize = '20px';
    
    headingTort.style.textAlign = 'center';
    headingTort.style.fontSize = '40px';
    headingTort.style.color = 'yellow';
    
    num1.style.fontSize = '20px';
    num1.style.color = 'red';
    
    num2.style.fontSize = '25px';
    num2.style.color = 'black';
    
    num3.style.fontSize = '30px';
    num3.style.color = 'green';
    
    btn.style.padding = '20px 40px';
    btn.style.border = 'none';
    btn.style.backgroundColor = 'blue';
})