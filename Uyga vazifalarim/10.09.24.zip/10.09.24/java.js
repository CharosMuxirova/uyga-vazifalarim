// // 1-
// let arr1 = [1, 2, 3, 4, 5, 7];
// let arr2 = [2, 3, 4, 6, 7, 4, 5];

// let difference = arr2.filter(num => !arr1.includes(num));

// console.log(difference); 

// // 2-
// function isBalanced(str) {
//     let balance = 0;
    
//     for (let char of str) {
//       if (char === '(') {
//         balance++;
//       } else if (char === ')') {
//         balance--;
//       }
      
//       if (balance < 0) {
//         return false;
//       }
//     }
    
//     return balance === 0;
//   }
  
//   console.log(isBalanced('()'));      // tori
//   console.log(isBalanced('())'));     // notori
//   console.log(isBalanced('('));       // notori
//   console.log(isBalanced(')))((('));  // notori

// //   3-
// function toggleCase(str) {
//     let result = '';
    
//     for (let char of str) {
//       if (char === char.toUpperCase()) {
//         result += char.toLowerCase();  
//       } else {
//         result += char.toUpperCase(); 
//       }
//     }
    
//     return result;
//   }
// //   misol
//   let input = "Bugun ob-havo savuq va yomg'li";
//   let output = toggleCase(input);
  
//   console.log(output); 
  

// //   4-

// function findUniqueElements(arr1, arr2) {
//     let onlyInArr1 = arr1.filter(element => !arr2.includes(element));
    
//     let onlyInArr2 = arr2.filter(element => !arr1.includes(element));
    
//     return onlyInArr1.concat(onlyInArr2);
//   }
  
//   // misol:
//   let arr1 = [1, 2, 3, 4, 5];
//   let arr2 = [3, 4, 5, 6, 7];
  
//   let result = findUniqueElements(arr1, arr2);
  
//   console.log(result); 

// //   5-

// function flattenAndSort(arr) {
//     let flattenedArray = arr.flat(Infinity); 
  
//     flattenedArray.sort((a, b) => a - b);
  
//     return flattenedArray;
//   }
  
//   // misol:
//   let mixedArray = [ [3, 2, 1], [5, 4], [8, 7, 6], 9, [10] ];
  
//   let result = flattenAndSort(mixedArray);
  
//   console.log(result); 

// //   6-

// function createSubarrays(arr) {
//     let subarrays = [];
    
//     for (let i = 0; i < arr.length - 1; i++) {
//       subarrays.push([arr[i], arr[i + 1]]);
//     }
    
//     return subarrays;
//   }
  
//   // misol:
//   let arr = [1, 2, 3, 4];
  
//   let result = createSubarrays(arr);
  
//   console.log(result); // [[1, 2], [2, 3], [3, 4]]

  
// //   7-
// function countRepeatedColors(arr) {
//     let colorCounts = {}; t
    
//     for (let color of arr) {
//       colorCounts[color] = (colorCounts[color] || 0) + 1;
//     }
    
//     let pairCount = 0;
//     for (let color in colorCounts) {
//       pairCount += Math.floor(colorCounts[color] / 2);
//     }
    
//     return pairCount;
//   }
  
//   // misol:
//   let colors = ['red', 'black', 'green', 'red', 'black', 'black', 'green', 'green', 'green',];
  
//   let result = countRepeatedColors(colors);
  
//   console.log(result); 
  