// 1
class Person {
    constructor(name, age) {
        this.name = name; 
        this.age = age;  
    }
    introduce() {
        console.log(`Salom, mening ismim ${this.name}, yoshim ${this.age}da.`);
    }
}
let person1 = new Person("Charos", 19);
person1.introduce();



// 2
class Person {
    constructor(name, age) {
        this.name = name; 
        this.age = age; 
    }
    introduce() {
        console.log(`Salom, mening ismim ${this.name}, yoshim ${this.age}da.`);
    }
}

class Talaba extends Person {
    constructor(name, age, studentID, major) {
        super(name, age); 
        this.studentID = studentID; 
        this.major = major;        
    }
    introduce() {
        console.log(`Salom, mening ismim ${this.name}, yoshim ${this.age}da. Talaba ID: ${this.studentID}, mutaxassisligim: ${this.major}.`);
    }
}

let student1 = new Talaba("Charos", 19, "ST06052005", "Dasturlash");
student1.introduce();


// 3
class Tortburchak {
    constructor(width, height) {
        this.width = width;  
        this.height = height; 
    }
    getArea() {
        return this.width * this.height;
    }
    getPerimeter() {
        return 2 * (this.width + this.height);
    }
}

let rectangle = new Tortburchak(6, 18);

console.log("Yuzi:", rectangle.getArea());       
console.log("Perimetri:", rectangle.getPerimeter()); 


// 4
class Avtomobil {
    constructor(brand, model, year) {
        this.brand = brand;  
        this.model = model; 
        this.year = year;   
    }
    drive() {
        console.log(`Avtomobil ${this.brand} ${this.model} haydashga tayyor.`);
    }
}

let car1 = new Avtomobil("Toyota", "Camry", 2020);
car1.drive();



// 5
class BankHisobi {
    constructor() {
        this.balance = 0; 
    }

    deposit(amount) {
        if (amount > 0) {
            this.balance += amount; 
            console.log(`${amount} so'm hisobga qo'shildi.`);
        } else {
            console.log("Iltimos, musbat miqdorda pul kiriting.");
        }
    }

   
    withdraw(amount) {
        if (amount > 0 && amount <= this.balance) {
            this.balance -= amount; 
            console.log(`${amount} so'm hisobdan yechildi.`);
        } else if (amount > this.balance) {
            console.log("Hisobda yetarli mablag' yo'q.");
        } else {
            console.log("Iltimos, musbat miqdorda pul yeching.");
        }
    }

    checkBalance() {
        console.log(`Hisobdagi qoldiq: ${this.balance} so'm.`);
    }
}
let myAccount = new BankHisobi();

myAccount.deposit(100000);
myAccount.withdraw(30000);
myAccount.checkBalance(); 
