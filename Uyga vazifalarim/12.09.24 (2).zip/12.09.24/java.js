// // 1-
// let myObject = {};
// myObject.name = "Charos";
// console.log(myObject.name); 


// // 2-
// let name = prompt("Ismingizni kiriting:");
// let age = prompt("Yoshingizni kiriting:");
// let user = {
//     name: name,
//     age: age
// };

// console.log(user);



// // 3-
// let name = prompt("Ismingizni kiriting:");
// let age = prompt("Yoshingizni kiriting:");

// let user = {
//     name: name,
//     age: age
// };
// user.profession = "Dasturchi";
// console.log(user.profession); 



// // 4-
// let car = {
//     brand: "Toyota",
//     model: "Camry",
//     year: 2020
// };
// car.brand = "Chevrolet";
// car.model = "Jentra";
// car.year = 2024;

// console.log(car.brand);  
// console.log(car.model); 
// console.log(car.year);  



// // 5-
// let person = {
//     name: "Charos",
//     age: 19,
//     profession: "dasturchi"
// };
// let text = `Mening ismim ${person.name}, yoshim ${person.age}da va men ${person.profession}man.`;
// console.log(text);



// // 6-
// let person = {
//     name: "Charos",
//     age: 19,
//     profession: "dasturchi"
// };
// let text = `Mening ismim ${person.name}, yoshim ${person.age}da va men ${person.profession}man.`;
// person.description = text;
// console.log(person.description);




// // 7
// let person = {
//     name: "Charos",
//     age: 19
// };

// if (person.age > 16) {
//     console.log("Siz Astrumda o'qisangiz bo'ladi.");
// } else {
//     console.log("Xali yoshsiz, siz maktabni tugatib keling.");
// }



// // 8-
// let person = {
//     name: "Charos",
//     age: 19,
//     profession: "dasturchi"
// };
// let personArray = [person.name, person.age, person.profession];
// console.log(personArray);


