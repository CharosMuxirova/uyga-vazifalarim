// // 1
// let mevalar = ["olma", "banan", "uzum", "anor", "shaftoli"];

// mevalar.forEach(function(meva) {
//     console.log(meva.toUpperCase());
// });


// // 2-
// function engKattaVaEngKichik(massiv) {
//     let engKichik = Math.min(...massiv);
//     let engKatta = Math.max(...massiv);
//     return { engKichik, engKatta };
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let natija = engKattaVaEngKichik(sonlarMassivi);
// console.log("Eng kichik son: " + natija.engKichik);
// console.log("Eng katta son: " + natija.engKatta);



// // 3-
// function juftSonlarYigindisi(massiv) {
//     let yigindi = 0;
//     massiv.forEach(function(son) {
//         if (son % 2 === 0) {
//             yigindi += son;
//         }
//     });
//     return yigindi;
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let yigindi = juftSonlarYigindisi(sonlarMassivi);
// console.log("Juft sonlar yig'indisi: " + yigindi);



// // 4
// function teskariTartibda(massiv) {
//     return massiv.slice().reverse(); // slice() yordamida yangi massiv yaratamiz
// }

// let sonlarMassivi = [10, 23, -5, 44, 0, -12, 37];

// let teskariMassiv = teskariTartibda(sonlarMassivi);
// console.log("Teskari tartibdagi massiv: " + teskariMassiv);



// // 5
// function faqatStringElementlar(massiv) {
//     return massiv.filter(function(element) {
//         return typeof element === 'string';
//     });
// }

// let aralashMassiv = ["salom", 2, true, "hi", "hello", "ok", null, 232];

// let stringElementlar = faqatStringElementlar(aralashMassiv);
// console.log("String elementlardan iborat yangi massiv: " + stringElementlar);



// // 6

// function ortachaArifmetik(massiv) {
//     let yigindi = massiv.reduce(function(akkumulyator, son) {
//         return akkumulyator + son;
//     }, 0);
//     return yigindi / massiv.length;
// }

// let sonlarMassivi = [3, 5, 7, 2, 4];

// let ortacha = ortachaArifmetik(sonlarMassivi);
// console.log("O'rtacha arifmetik qiymat: " + ortacha);



// // 7
// function kopaytmaHisobla(massiv) {
//     return massiv.reduce(function(akkumulyator, son) {
//         return akkumulyator * son;
//     }, 1);
// }

// let sonlarMassivi = [3, 5, 7, 2, 4];

// let kopaytma = kopaytmaHisobla(sonlarMassivi);
// console.log("Sonlarning ko'paytmasi: " + kopaytma);



// // 8
// function toqSonlarOrtacha(massiv) {
//     let toqSonlar = massiv.filter(function(son) {
//         return son % 2 !== 0;
//     });

//     if (toqSonlar.length === 0) {
//         return null; 
//     }

//     let yigindi = toqSonlar.reduce(function(akkumulyator, son) {
//         return akkumulyator + son;
//     }, 0);
    
//     return yigindi / toqSonlar.length;
// }

// let sonlarMassivi = [3, 5, 7, 2, 4, 10, 15];

// let ortacha = toqSonlarOrtacha(sonlarMassivi);
// console.log("Toq sonlarning o'rtacha arifmetik qiymati: " + ortacha);


// // 9-
// let arr1 = [1, 2, 3, 4, 5, 7];
// let arr2 = [2, 3, 4, 6, 7, 4, 5];

// let difference = arr2.filter(num => !arr1.includes(num));

// console.log(difference); 

// // 10-
// function isBalanced(str) {
//     let balance = 0;
    
//     for (let char of str) {
//       if (char === '(') {
//         balance++;
//       } else if (char === ')') {
//         balance--;
//       }
      
//       if (balance < 0) {
//         return false;
//       }
//     }
    
//     return balance === 0;
//   }
  
//   console.log(isBalanced('()'));      // tori
//   console.log(isBalanced('())'));     // notori
//   console.log(isBalanced('('));       // notori
//   console.log(isBalanced(')))((('));  // notori

// //   11-
// function toggleCase(str) {
//     let result = '';
    
//     for (let char of str) {
//       if (char === char.toUpperCase()) {
//         result += char.toLowerCase();  
//       } else {
//         result += char.toUpperCase(); 
//       }
//     }
    
//     return result;
//   }
// //   misol
//   let input = "Bugun ob-havo savuq va yomg'li";
//   let output = toggleCase(input);
  
//   console.log(output); 
  

// //   12-

// function findUniqueElements(arr1, arr2) {
//     let onlyInArr1 = arr1.filter(element => !arr2.includes(element));
    
//     let onlyInArr2 = arr2.filter(element => !arr1.includes(element));
    
//     return onlyInArr1.concat(onlyInArr2);
//   }
  
//   // misol:
//   let arr1 = [1, 2, 3, 4, 5];
//   let arr2 = [3, 4, 5, 6, 7];
  
//   let result = findUniqueElements(arr1, arr2);
  
//   console.log(result); 

// //   13-

// function flattenAndSort(arr) {
//     let flattenedArray = arr.flat(Infinity); 
  
//     flattenedArray.sort((a, b) => a - b);
  
//     return flattenedArray;
//   }
  
//   // misol:
//   let mixedArray = [ [3, 2, 1], [5, 4], [8, 7, 6], 9, [10] ];
  
//   let result = flattenAndSort(mixedArray);
  
//   console.log(result); 

// //   14-

// function createSubarrays(arr) {
//     let subarrays = [];
    
//     for (let i = 0; i < arr.length - 1; i++) {
//       subarrays.push([arr[i], arr[i + 1]]);
//     }
    
//     return subarrays;
//   }
  
//   // misol:
//   let arr = [1, 2, 3, 4];
  
//   let result = createSubarrays(arr);
  
//   console.log(result); // [[1, 2], [2, 3], [3, 4]]

  
// //   15-
// function countRepeatedColors(arr) {
//     let colorCounts = {}; t
    
//     for (let color of arr) {
//       colorCounts[color] = (colorCounts[color] || 0) + 1;
//     }
    
//     let pairCount = 0;
//     for (let color in colorCounts) {
//       pairCount += Math.floor(colorCounts[color] / 2);
//     }
    
//     return pairCount;
//   }
  
//   // 16 misol:
//   let colors = ['red', 'black', 'green', 'red', 'black', 'black', 'green', 'green', 'green',];
  
//   let result = countRepeatedColors(colors);
  
//   console.log(result); 
  