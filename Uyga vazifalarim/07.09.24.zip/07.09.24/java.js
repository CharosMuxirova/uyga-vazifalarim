// // 12
// function engKattaSon(a, b, c, d, e) {
//     let engKatta = a; 

//     if (b > engKatta) {
//         engKatta = b;
//     }
//     if (c > engKatta) {
//         engKatta = c;
//     }
//     if (d > engKatta) {
//         engKatta = d;
//     }
//     if (e > engKatta) {
//         engKatta = e;
//     }

//     alert("Eng katta son: " + engKatta);
// }
// engKattaSon(45, 72, 13, 56, 88);


// // 13-
// function oxirgiRaqamBirXilmi(a, b, c) {
//     let oxirgiRaqamA = a % 10;
//     let oxirgiRaqamB = b % 10;
//     let oxirgiRaqamC = c % 10;

//     if (oxirgiRaqamA === oxirgiRaqamB && oxirgiRaqamB === oxirgiRaqamC) {
//         alert("Uchta sonning oxirgi raqami bir xil.");
//     } else {
//         alert("Uchta sonning oxirgi raqami bir xil emas.");
//     }
// }

// oxirgiRaqamBirXilmi(123, 43, 93); 


// // 14-
// for (let i = 0; i <= 15; i++) {
//     if (i % 2 === 0) {
//         console.log(i + " juft son");
//     } else {
//         console.log(i + " toq son");
//     }
// }






// // 15
// for (let i = 1; i <= 100; i++) {
//     if (i % 3 === 0 && i % 5 === 0) {
//         console.log("FizzBuzz");
//     } else if (i % 3 === 0) {
//         console.log("Fizz");
//     } else if (i % 5 === 0) {
//         console.log("Buzz");
//     } else {
//         console.log(i);
//     }
// }

