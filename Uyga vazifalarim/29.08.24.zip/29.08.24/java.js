// //  №1
// let testScore1 = 85;
// let testScore2 = 90; 
// let testScore3 = 78; 
// let totalScore = testScore1 + testScore2 + testScore3;
// let averageScore = totalScore / 3;
// console.log("O'rtacha ball:", averageScore);



// //  №2
// let firstName = prompt("Ismingizni kiriting:");  
// let lastName = prompt("Familiyangizni kiriting:"); 
// alert(`Salom ${firstName} ${lastName} Astrumga xush kelibsiz`);


// // №3
// let firstNumber = parseFloat(prompt("Birinchi raqamingizni kiriting:"));
// let secondNumber = parseFloat(prompt("Ikkinchi raqamingizni kiriting:"));

// let additionResult = firstNumber + secondNumber;
// let subtractionResult = firstNumber - secondNumber;
// let multiplicationResult = firstNumber * secondNumber;
// let divisionResult = firstNumber / secondNumber;

// console.log(`Qo'shish natijasi: ${additionResult}`);
// console.log(`Ayirish natijasi: ${subtractionResult}`);
// console.log(`Ko'paytirish natijasi: ${multiplicationResult}`);
// console.log(`Bo'lish natijasi: ${divisionResult}`);


// // №4
// let celsius = parseFloat(prompt("Selsiy bo'yicha harorat qiymatini kiriting:"));
// let fahrenheit = (celsius * 9 / 5) + 32;
// let kelvin = celsius + 273.15;

// alert(`Selsiy: ${celsius}°C\nFarengeyt: ${fahrenheit}°F\nKelvin: ${kelvin} K`);


// // №5
// let length = parseFloat(prompt("To'rtburchakning uzunligini kiriting (masalan, 5.0):"));
// let width = parseFloat(prompt("To'rtburchakning kengligini kiriting (masalan, 3.0):"));

// let area = length * width;

// alert(`To'rtburchakning maydoni: ${area} m²`);


// // №6
// let length = parseInt(prompt("To'rtburchakning uzunligini kiriting (masalan, 5):"));
// let width = parseInt(prompt("To'rtburchakning kengligini kiriting (masalan, 7):"));

// let area = length * width;
// let perimeter = 2 * (length + width);

// alert(`To'rtburchakning maydoni: ${area}\nTo'rtburchakning perimetri: ${perimeter}`);
