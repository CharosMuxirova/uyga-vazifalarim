// // 8-
// function kopaytirishJadvali(n) {
//     for (let i = 1; i <= n; i++) {
//         let qator = '';
//         for (let j = 1; j <= n; j++) {
//             qator += (i * j) + '\t'; 
//         }
//         console.log(qator); 
//     }
// }

// kopaytirishJadvali(50);



// // 9-
// function tubSonlarChopEt(n) {

//     for (let i = 2; i <= n; i++) {
//        let tub = true; 
//          for (let j = 2; j < i; j++) {
//             if (i % j === 0) {
//                 tub = false; 
//                 break; 
//             }
//         }
//         if (tub) {
//             console.log(i);
//         }
//     }
// }
// tubSonlarChopEt(50);
